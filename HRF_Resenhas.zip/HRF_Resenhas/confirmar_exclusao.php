<?php
	include 'cabecalho.php';
?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<center><h2>Confirmação de Senha</h2></center>
    <div class="formulario_login">
        <form class="ui form">
            <div class="field">
                <label class="negrito">Senha</label>
                <input type="password" name="first-name" placeholder="Senha">
            </div>
        </form>
        <h4 class="recupercao_senha">Esqueci minha senha</h4>
        <button class="ui google plus button para_lado">
            Confirmar
			<i class="caret square right icon"></i>
		</button>
    </div>
	<br>