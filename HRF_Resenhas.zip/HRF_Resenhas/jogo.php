<?php
	include 'cabecalho.php';
	include 'functions.php';

	$codigo = $_GET['cod'];
	$jogo = buscaJogo($codigo);
	$requisitos_minimos = buscaRequisitosMinimos($codigo);
	$requisitos_recomendados = buscaRequisitosRecomendados($codigo);
?>
	<br>
	<br>
	<br>
	<br>
	<center><h2><?= $jogo['nome_jogo']?></h2></center>
	<br>

	<p class="texto_resenha"><?= $jogo['resenha']?></p>

	<center><img src="imagem/<?= $jogo['imagem_resenha']?>"></center>
	<br>

		<p class="texto_resenha">Requisitos Minímos:</p>
			<ul>
				<li class="texto_resenha"><p>Sistema Operacional:<?= $requisitos_minimos['os'] ?></p></li>
				<li class="texto_resenha"><p>CPU: <?= $requisitos_minimos['cpu'] ?></p></li>
				<li class="texto_resenha"><p>RAM: <?= $requisitos_minimos['ram'] ?></p></li>
				<li class="texto_resenha"><p>Placa de Vídeo: <?= $requisitos_minimos['video'] ?></p></li>
				<li class="texto_resenha"><p>Armazenamento: <?= $requisitos_minimos['hdd']?></p></li>
				<?php
					if($requisitos_minimos['directx'] !=0){
						print ('<li class= "texto_resenha"><p>DirectX:'.$requisitos_minimos['directx'].'</p></li>');
					}
				?>
			</ul>
	<br>
		<p class="texto_resenha">Requisitos Recomendados: </p>
			<ul>
				<li class="texto_resenha"><p>Sistema Operacional:<?= $requisitos_recomendados['os'] ?></p></li>
				<li class="texto_resenha"><p>CPU: <?= $requisitos_recomendados['cpu'] ?></p></li>
				<li class="texto_resenha"><p>RAM: <?= $requisitos_recomendados['ram'] ?></p></li>
				<li class="texto_resenha"><p>Placa de Vídeo: <?= $requisitos_recomendados['video'] ?></p></li>
				<li class="texto_resenha"><p>Armazenamento: <?= $requisitos_recomendados['hdd']?></p></li>
				<?php
					if($requisitos_recomendados['directx'] !=0){
						print ('<li class= "texto_resenha"><p>DirectX:'.$requisitos_recomendados['directx'].'</p></li>');
					}
				?>
			</ul>
	<br>
	<div class="excluir">	
		<a href="confirmar_exclusao.php">
			<button class="ui google plus button para_lado confirmar_exclusao">
				<i class="trash alternate outline icon"></i>
					Excluir
			</button>
		</a>
		<a href="editar.php">	
			<button class="ui google plus button para_lado">
				<i class="pencil alternate icon"></i>
				Editar
			</button>
		</a>
	</div>
	<?php
	include 'rodape.php';
	?>