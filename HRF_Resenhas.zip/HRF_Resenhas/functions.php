<?php
function buscaJogo($cod_jogo){

	$jogo = array();
	$dados = file("dados/hrf_resenha.csv"); // abre o arquivo 

	foreach ($dados as $key => $value) { // percorre as linhas do arquivo
		$colunas = explode(";", $value); // separa as colunas do arquivo

		if ($cod_jogo == $colunas[0]) { // teste se o codigo existe

			$jogo['cod_jogo'] = $colunas[0];
			$jogo['nome_jogo'] = $colunas[1];
			$jogo['resenha'] = $colunas[2];
			$jogo['imagem_resenha'] = $colunas[3];
		}
	}
	return $jogo;
}

function buscaRequisitosMinimos($cod_jogo){

	$requisitos = array();
	$dados = file("dados/requisitos_minimos.csv"); // abre o arquivo 

	foreach ($dados as $key => $value) { // percorre as linhas do arquivo
		$colunas = explode(";", $value); // separa as colunas do arquivo

		if ($cod_jogo == $colunas[0]) { // teste se o codigo existe

			$requisitos['cod_jogo'] = $colunas[0];
			$requisitos['os'] = $colunas[1];
			$requisitos['cpu'] = $colunas[2];
			$requisitos['ram'] = $colunas[3];
			$requisitos['video'] = $colunas[4];
			$requisitos['hdd'] = $colunas[5];
			$requisitos['directx'] = $colunas[6];
		}
	}
	return $requisitos;
}

function buscaRequisitosRecomendados($cod_jogo){

	$requisitos = array();
	$dados = file("dados/requisitos_recomendados.csv"); // abre o arquivo

	foreach ($dados as $key => $value) { // percorre as linhas do arquivo
		$colunas = explode(";", $value); // separa as colunas do arquivo

		if ($cod_jogo == $colunas[0]) { // teste se o codigo existe

			$requisitos['cod_jogo'] = $colunas[0];
			$requisitos['os'] = $colunas[1];
			$requisitos['cpu'] = $colunas[2];
			$requisitos['ram'] = $colunas[3];
			$requisitos['hdd'] = $colunas[4];
			$requisitos['video'] = $colunas[5];
			$requisitos['directx'] = $colunas[6];
		}
	}
	return $requisitos;
}

function buscaMinhasResenhas($cod_jogo){

	$minhas_resenhas = array();
	$dados = file("dados/minhas_resenhas.csv"); // abre o arquivo

	foreach ($dados as $key => $value) { // percorre as linhas do arquivo
		$colunas = explode(";", $value); // separa as colunas do arquivo

		if ($cod_jogo == $colunas[0]) { // teste se o codigo existe

			$minhas_resenhas['cod_jogo'] = $colunas[0];
			$minhas_resenhas['nome_jogo'] = $colunas[1];
			$minhas_resenhas['minha_resenha'] = $colunas[2];
		}
	}
	return $minhas_resenhas;

}

function listaMinhasResenhas(){
		
		$dados= file("dados/minhas_resenhas.csv");
		$jogo = array();
		$jogos = array();

		foreach ($dados as $key => $value) { // percorre as linhas do arquivo
			if ($key != 0) {
				$colunas = explode(";", $value); // separa as colunas do arquivo

				$jogo['cod_jogo'] = $colunas[0];
				$jogo['nome_jogo'] = $colunas[1];
				$jogo['criada_em'] = $colunas[2];
				$jogo['minha_resenha'] = $colunas[3];
				$jogo['imagem'] = $colunas[4];
				$jogo['link'] = $colunas[5];
		
				$jogos[] = $jogo;
			}		
		}
		return $jogos;
	}

function listaJogos(){
		
		$dados= file("dados/index.csv");
		$jogo = array();
		$jogos = array();

		foreach ($dados as $key => $value) { // percorre as linhas do arquivo
			if ($key != 0) {
				$colunas = explode(";", $value); // separa as colunas do arquivo

				$jogo['cod_jogo'] = $colunas[0];
				$jogo['imagem_index'] = $colunas[1];
				$jogo['nome_jogo'] = $colunas[2];
				$jogos[] = $jogo;
			}		
		}
		return $jogos;
	}

function buscaUsuario($usuariop){
$usuario = array();
	$dados = file("usuarios.csv"); // abre o arquivo 

	foreach ($dados as $value) { // percorre as linhas do arquivo
		$colunas = explode(";", $value); // separa as colunas do arquivo

		if ($usuariop == $colunas[2]) { // teste se o codigo existe
			$usuario['cod_usu'] = $colunas[0];
			$usuario['nome_usu'] = $colunas[1];
			$usuario['email_usu'] = $colunas[2];
			$usuario['senha'] = $colunas[3];

		}
	}
	return $usuario;
}




?>