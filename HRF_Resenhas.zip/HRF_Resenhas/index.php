	<?php
	include 'cabecalho.php';
	include 'functions.php';

	$lista = listaJogos();
	?>
	<br>
	<br>
	<br>
	<br>
	<center><h1 class="title">Resenhas em Destaque!</h1></center>
	<br>
	<?php



	echo" <div class='espaco'>
	<div class='ui two grid'>
	";


	foreach ($lista as $jogo) {

		echo ("



			<div class='column six wide'>
			<div class='ui raised segment'>
			<a href='jogo.php?cod=".$jogo['cod_jogo']."'>
			<img class='ui image' src='imagem/".$jogo['imagem_index']."'>
			<div class='ui bottom attached label'>
			".$jogo['nome_jogo']."
			<div class='extra'>
			<div class='ui star rating' data-max-rating='5' data-rating='3'></div>	
			</div>
			</div>
			</a>
			</div>
			</div>	









			");
	}
	echo" </div>
	</div>";

	?>
	<script>
		$('.ui.rating').rating();
	</script>
	<?php
	include 'rodape.php';




// <div class='ui four cards'>
// 						  <div class='card'>
// 						  	<a href='jogo.php?cod=".$jogo['cod_jogo']."'>
// 							    <div class='image'>
// 							      <img class='ui image' src='imagem/".$jogo['imagem_index']."'>
// 							    </div>
// 							    <div class='extra'>
// 							      ".$jogo['nome_jogo']."
// 							      <div class='ui star rating' data-rating='4'></div>
// 							    </div>
// 							</a>
// 						  </div>
// 						</div>					




	?>