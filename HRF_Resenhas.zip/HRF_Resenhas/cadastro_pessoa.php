<?php

include "cabecalho.php";

?>
<br>
<br>
<div class="formulario">
	<center><h3>Cadastro de Pessoa</h3></center>
	<br>
	<form class="ui form">
		<div class="field">
			<label>Nome Completo</label>
			<input type="text" name="first-name" placeholder="Nome Completo">
        </div>
        <div class="field">
			<label>Apelido</label>
			<input type="text" name="first-name" placeholder="Apelido">
        </div>
        <div class="field">
			<label>E-mail</label>
			<input type="text" name="first-name" placeholder="E-mail">
        </div>
        <div class="field">
			<label>Senha</label>
			<input type="password" name="first-name" placeholder="Senha">
        </div>
        <div class="field">
			<label>Confirmação de Senha</label>
			<input type="password" name="first-name" placeholder="Confirmação de Senha">
        </div>
		<div>
			<label class="negrito">Avatar</label>
			<br>
			<label for="file" class="ui icon button">
				<i class="os image icon"></i>
			Abrir arquivo</label>
			<input type="file" id="file" style="display:none">
		</div>
		<br>	
		<div class="field">
			<div class="ui checkbox">
				<input type="checkbox" tabindex="0" class="hidden">
				<label>Eu concordo com os termos e condições</label>
			</div>
		</div>
		<button class="ui google plus button para_lado">
			  <i class="location arrow icon"></i>
			  Cadastrar
		</button>
		<br>
		<br>
	</form>
</div>

<?php
include "rodape.php";
?>