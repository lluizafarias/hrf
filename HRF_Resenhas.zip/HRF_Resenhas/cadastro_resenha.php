<?php

include "cabecalho.php";

?>
<br>
<br>
<div class="formulario">
	<center><h3>Cadastro de Resenha</h3></center>
	<br>
	<form class="ui form">
		<div class="field">
			<label>Nome do Jogo</label>
			<input type="text" name="first-name" placeholder="Nome do Jogo">
		</div>
		<div>
			<label class="negrito">Resenha</label>
			<textarea placeholder="Resenha"></textarea>
		</div>
		<br>
		<div>
			<label class="negrito">Imagem do Jogo</label>
			<br>
			<label for="file" class="ui icon button">
				<i class="os image icon"></i>
			Abrir arquivo</label>
			<input type="file" id="file" style="display:none">
		</div>
		<br>
		<br>
			<center><h3>Requisítos Minímos</h3></center>
		<br>
		<br>
		<div class="fields">
			<div class="field">
				<label>Sistema Operacional</label>
				<input type="text" placeholder="Sistema Operacional">
			</div>
			<div class="field">
				<label>Processador</label>
				<input type="text" placeholder="Processador">
			</div>
			<div class="field">
				<label>Memória RAM</label>
				<input type="text" placeholder="Memória RAM">
			</div>
		</div>	
		<div class="fields">
			<div class="field">
				<label>Placa de Vídeo</label>
				<input type="text" placeholder="Placa de Vídeo">
			</div>
			<div class="field">
				<label>DirectX</label>
				<input type="text" placeholder="DirectX">
			</div>
			<div class="field">
				<label>Armazenamento</label>
				<input type="text" placeholder="Armazenamento">
			</div>
		</div>	
		<br>
		<br>
			<center><h3>Requisítos Recomendados</h3></center>
		<br>
		<br>
		<div class="fields">
			<div class="field">
				<label>Sistema Operacional</label>
				<input type="text" placeholder="Sistema Operacional">
			</div>
			<div class="field">
				<label>Processador</label>
				<input type="text" placeholder="Processador">
			</div>
			<div class="field">
				<label>Memória RAM</label>
				<input type="text" placeholder="Memória RAM">
			</div>
		</div>	
		<div class="fields">
			<div class="field">
				<label>Placa de Vídeo</label>
				<input type="text" placeholder="Placa de Vídeo">
			</div>
			<div class="field">
				<label>DirectX</label>
				<input type="text" placeholder="DirectX">
			</div>
			<div class="field">
				<label>Armazenamento</label>
				<input type="text" placeholder="Armazenamento">
			</div>
		</div>
		<br>	
		<div class="field">
			<div class="ui checkbox">
				<input type="checkbox" tabindex="0" class="hidden">
				<label>Eu concordo com os termos e condições</label>
			</div>
		</div>
		<a href="minhas_resenhas.php">
			<button class="ui google plus button para_lado">
				  <i class="location arrow icon"></i>
				  Cadastrar
			</button>
		</a>
		<br>
		<br>
	</form>
</div>

<?php
include "rodape.php";
?>