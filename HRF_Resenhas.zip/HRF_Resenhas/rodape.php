<br>
<br>
 <center><div class="ui red inverted vertical footer segment footer">
    <div class="ui center aligned container">
      <div class="ui stackable inverted divided grid">
        <div class="three wide column centered">
          <h4 class="ui inverted header">Criadores</h4>
          <div class="ui inverted link list">
            <a href="https://www.instagram.com/lluizafarias/" class="item" target="_blank">Luiza Farias</a>
            <a href="https://www.instagram.com/matheus_hquintino/" class="item" target="_blank">Matheus Henrique Quintino</a>
            <a href="https://www.instagram.com/matheusilva22/" class="item" target="_blank">Matheus Rodrigues da Silva</a>
          </div>
        </div>
        
        <div class="seven wide column">
          <h4 class="ui inverted header">HRF Resenhas</h4>
          <p>O melhor do mundo FPS</p>
        </div>
      </div>
      <br>
      <br>
      <a href="https://pt-br.facebook.com/">
      <button class="black ui facebook button">
  <i class="facebook icon"></i>
  Facebook
</button>
</a>
<a href="https://twitter.com/login?lang=pt">
<button class="black ui twitter button">
  <i class="twitter icon"></i>
  Twitter
</button>
</a>
<a href="https://www.instagram.com/?hl=pt-br">
<button class="black ui instagram button">
  <i class="instagram icon"></i>
  Instagram
</button>
</a>
<br>
      <div class="ui horizontal inverted small divided link list">
        <a class="item" href="#">Site Map</a>
        <a class="item" href="#">Contact Us</a>
        <a class="item" href="#">Terms and Conditions</a>
        <a class="item" href="#">Privacy Policy</a>
      </div>
    </div>
</div>
</center>
</body>
</html>