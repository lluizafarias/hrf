<?php
include 'cabecalho.php';
include 'functions.php';

	$minhas_resenhas = listaMinhasResenhas();
?>

<br>
<br>
<br>
<br>
<br>
<br>
<?php
	
	foreach ($minhas_resenhas as $jogo) {
		
		echo ("<div class='alinhar_minhas_resenhas'>
			<div class='ui divided items'>
			  <div class='item'>
			    <div class='image'>
			      <img src='".$jogo['imagem']."'>
			    </div>
			    <div class='content'>
			      <a class='header'>".$jogo['nome_jogo']."</a>
			      <div class='meta'>
			        <span class='cinema'>Criada em: ".$jogo['criada_em']."</span>
			      </div>
			      <div class='description'>
			        <p></p>
			      </div>
			      <div class='extra'>
			      	<a href='jogo.php?cod=".$jogo['cod_jogo']."'>
				        <div class='ui right floated primary button google plus'>
				          Veja Mais
				          <i class='right chevron icon'></i>
				        </div>
				    </a>
				    <a href='editar.php'>
				        <div class='ui right floated primary button google plus'>
				          <i class='pencil alternate icon'></i>
				          Editar
				        </div>
				    </a>
				    <a href='confirmar_exclusao.php'>
				        <div class='ui right floated primary button google plus'>
				          <i class='trash alternate outline icon'></i>
				          Excluir
				        </div>
				    </a>
			      </div>
			    </div>
			  </div>
			</div>
		</div>
		<br>");
	}
?>
<div class="margem_rodape">
	.
</div>
<?php
include 'rodape.php';
